let currentLang = 'de';

const translations = {
  de: {
    title: "Willkommen auf dem Minecraft Server",
    btn_ip: "🟢 Server IP anzeigen",
    btn_links: "🔗 Nützliche Links",
    back_home: "🔙 Zurück zur Startseite",
    links_title: "Nützliche Links",
  },
  en: {
    title: "Welcome to the Minecraft Server",
    btn_ip: "🟢 Show Server IP",
    btn_links: "🔗 Useful Links",
    back_home: "🔙 Back to Home",
    links_title: "Useful Links",
  }
};

function toggleLanguage() {
  currentLang = currentLang === 'de' ? 'en' : 'de';
  document.getElementById('currentLang').innerText =
    currentLang === 'de' ? "Aktuelle Sprache: Deutsch" : "Current language: English";

  document.querySelectorAll('[data-translate]').forEach(el => {
    const key = el.getAttribute('data-translate');
    el.textContent = translations[currentLang][key];
  });
}

function showIP() {
  document.getElementById('ipDisplay').style.display = 'block';
}